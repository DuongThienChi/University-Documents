#ifndef _FLASHSORT_H_
#define _FLASHSORT_H_

void flashSort(int* a, int n);

long long flashSortWithCounting(int* a, int n);

#endif // _FLASHSORT_H_